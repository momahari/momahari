<h1 align="center">
  Hi there 👋, I'm Mohamed
</h1>

<p align="center">
  <img src="https://readme-typing-svg.herokuapp.com?size=24&color=2F81F7&center=true&vCenter=true&width=500&lines=Electrical+Engineer+⚡;Software+Developer+💻;Open+Source+Enthusiast+🌍" alt="Typing animation" />
</p>

---

### 🚀 Tech Stack  
<p align="center">
  <img src="https://skillicons.dev/icons?i=python,cpp,cs,js,html,css,java,sql,django,flask,dotnet,nodejs,bootstrap,react,git,github,vscode,docker,linux" />
</p>

---

### 📊 GitHub Activity  
<p align="center">
  <img src="https://github-readme-stats.vercel.app/api?username=momahari&show_icons=true&theme=tokyonight" height="170px"/>
  <img src="https://github-readme-streak-stats.herokuapp.com/?user=momahari&theme=tokyonight" height="170px"/>
</p>

<p align="center">
  <img src="https://github-readme-activity-graph.vercel.app/graph?username=momahari&theme=tokyo-night" />
</p>

---

### 🐍 Contribution Snake  
<p align="center">
  <img src="https://raw.githubusercontent.com/momahari/momahari/output/snake.svg" alt="Snake animation" />
</p>
